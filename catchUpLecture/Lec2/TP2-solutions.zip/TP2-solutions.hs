{-          
EX: Consider a function safetail :: [ a ] → [ a ] that behaves as the library function tail , except that safetail maps the empty list to itself, whereas tail
produces an error in this case. Define safetail using:
(a) a conditional expression;
(b) guarded equations;
(c) pattern matching.
-}

safetailA :: [a] -> [a]
safetailA xs = if (null xs) then [] else tail xs 

safetailB :: [a] -> [a]
safetailB x 
    | null x = []
    | otherwise = tail x 

safetailC :: [a] -> [a]
safetailC [] = []
safetailC (x:xs) = xs 



{- Write a function converting Bool in String by using:
A)a conditional expression;
B)guarded equations;
C)pattern matching;
D)a standard prelude function;
E) case expressions.
-}

boolToStringA :: Bool -> String
boolToStringA x = if x then "True" else "False"

boolToStringB :: Bool -> String
boolToStringB x
    | x = "True"
    | otherwise = "False"

boolToStringC:: Bool -> String
boolToStringC  True  = "True"
boolToStringC False =  "False"  

boolToStringD :: Bool -> String
boolToStringD = show


boolToStringE :: Bool -> String
boolToStringE b = case b 
            of True -> "True"
               False -> "False"

                    

{-Show how the logical disjunction operator v (i.e.`||`) can be defined in four 
different ways using pattern matching.-}

orA :: Bool -> Bool -> Bool
orA False False = False
orA True True = True
orA True False = True
orA False True = True 

orB :: Bool -> Bool -> Bool 
orB False b = b
orB True _ = True


orC :: Bool -> Bool -> Bool
orC a b 
    | a == b = a
    | otherwise = True

orD :: Bool -> Bool -> Bool 
orD False False = False
orD _ _ = True



    
